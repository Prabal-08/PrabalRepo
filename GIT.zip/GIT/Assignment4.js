﻿ profile = {};
 var formValidity = true;
 var arrayString;
var objectString;

function createBtn1() {
    validateEmail();
    validateUsername();
    validatePassword();
    validatePostalCode(); 
    validateLastname();
    validateAddress();
    validateCity();
    validateProvince();
    validateAge();
    validateForm();
    convertToString();
  /* var form = document.getElementsByTagName("form")[0];
   if (form.addEventListener) {
      form.addEventListener("submit", validateForm, false);
   } else if (form.attachEvent) {
      form.attachEvent("onsubmit", validateForm);
   }*/
     
}
function validateEmail() {
    var emailInput = document.getElementById("emailbox");
    var errorDiv = document.getElementById("emailError");
    try {
        if (emailInput.value.search("@") === -1 || emailInput.value.lastIndexOf(".") === -1) {
            throw "please provide a valid email address";

        }
        emailInput.style.background = "";
        errorDiv.innerHTML = "";
        errorDiv.style.display = "none";
        emailInput.value = emailInput.value.toLowerCase();
        profile.email = emailInput.value;
        document.getElementById("profileEmail").innerHTML = profile.email;
        document.getElementById("profile").style.display = "block";
        document.getElementById("emailSection").style.display = "block";

    }
    catch (msg) {
        errorDiv.innerHTML = msg;
        errorDiv.style.display = "block";
        emailInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}
function validatePostalCode(){
var pInput = document.getElementById("pCode");
var errorDiv = document.getElementById("postalError");
try{
if(pInput.value.search("[A-Za-z][0-9][A-Za-z] [0-9][A-Za-z][0-9]")!=0)
{
throw "Postal code is not correct";
}
pInput.style.background = " ";
errorDiv.style.display="none";
errorDiv.innerHTML=" ";
profile.postal = pInput.value;

document.getElementById("profilePostal").innerHTML = profile.postal;
document.getElementById("profile").style.display = "block";
document.getElementById("postalSection").style.display = "block";
}
catch(msg){
errorDiv.style.display = "block";
errorDiv.innerHTML = msg;
pInput.style.background = "rgb(255,233,233)";
formValidity = false;
}
}
function validateUsername() {
    var unInput = document.getElementById("uname");
    var errorDiv = document.getElementById("usernameError");
    try {
        if (unInput.value.length < 1) {
            throw "Please fill your first name";
        }
        unInput.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profileusername = unInput.value;
        document.getElementById("profileUsername").innerHTML = profileusername;
        document.getElementById("profile").style.display = "block";
        document.getElementById("usernameSection").style.display = "block"; 
    }
    catch (msg) {
        errorDiv.style.display = "block";
        errorDiv.innerHTML = msg;
        unInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
    
}
function convertToString() {
   // convert profile object to string
   objectString = JSON.stringify(profile);
}

    
    function validateLastname() {
    var lInput = document.getElementById("lname");
    var errorDiv = document.getElementById("lnameError");
    try {
        if (lInput.value.length < 1) {
            throw "Please fill your Lastname";
        }
        lInput.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profilelastname = lInput.value;
        document.getElementById("profileLname").innerHTML = profilelastname;
        document.getElementById("profile").style.display = "block";
        document.getElementById("lnameSection").style.display = "block"; 
    }
    catch (msg) {
        errorDiv.style.display = "block";
        errorDiv.innerHTML = msg;
        lInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}

function validateAddress() {
    var adInput = document.getElementById("address");
    var errorDiv = document.getElementById("addressError");
    try {
        if (adInput.value.length < 1) {
            throw "Please fill your Address";
        }
        adInput.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profileAddress = adInput.value;
        document.getElementById("profileAddress").innerHTML = profileAddress;
        document.getElementById("profile").style.display = "block";
        document.getElementById("addressSection").style.display = "block"; 
    }
    catch (msg) {
        errorDiv.style.display = "block";
        errorDiv.innerHTML = msg;
        adInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}

function validateCity() {
    var ciInput = document.getElementById("city");
    var errorDiv = document.getElementById("cityError");
    try {
        if (ciInput.value.length < 1) {
            throw "Please fill your city";
        }
        ciInput.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profilecity = ciInput.value;
        document.getElementById("profileCity").innerHTML = profilecity;
        document.getElementById("profile").style.display = "block";
        document.getElementById("citySection").style.display = "block"; 
    }
    catch (msg) {
        errorDiv.style.display = "block";
        errorDiv.innerHTML = msg;
        ciInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}
function validateProvince() {
    var proInput = document.getElementById("province");
    var errorDiv = document.getElementById("provinceError");
        try {
        if (proInput.value.search() != "province" ){
            throw "please select a province";
        }

        proInput.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profileProvince = proInput.value;
        document.getElementById("profileProvince").innerHTML = profileProvince;
        document.getElementById("profile").style.display = "block";
        document.getElementById("ptovinceSection").style.display = "block"; 
    }
    catch (msg) {
        errorDiv.style.display = "block";
        errorDiv.innerHTML = msg;
        proInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}

function validateAge() {
    var agInput = document.getElementById("age");
    var errorDiv = document.getElementById("ageError");
    try {
        if (agInput.value < 18) {
            throw "please enter your age if your above 18";
        }
        agInput.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profileAge = agInput.value;
        document.getElementById("profileAge").innerHTML = profileAge;
        document.getElementById("profile").style.display = "block";
        document.getElementById("ageSection").style.display = "block"; 
    }
    catch (msg) {
        errorDiv.style.display = "block";
        errorDiv.innerHTML = msg;
        agInput.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}


/*function validatePassword() {
    var pw1Input = document.getElementById("pw1");
    var pw2Input = document.getElementById("pw2");
    var errorDiv = document.getElementById("passwordError");
    try {
        if (pw1Input.value.length < 8) {
            throw "Password must be at least 8 characters";
        } else if (pw1Input.value.localeCompare(pw2Input.value) !== 0) {
            throw "Passwords must match";
        }
        pw1Input.style.background = "";
        pw2Input.style.background = "";
        errorDiv.style.display = "none";
        errorDiv.innerHTML = "";
        profile.password = pw1Input.value;
    }
    catch (msg) {
        errorDiv.style = "block";
        errorDiv.innerHTML = msg;
        pw1Input.style.background = "rgb(255,233,233)";
        pw2Input.style.background = "rgb(255,233,233)";
        formValidity = false;
    }
}*/
function validatePassword() {
   var pw1Input = document.getElementById("pw1");
   var pw2Input = document.getElementById("pw2");
   var errorDiv = document.getElementById("passwordError");
   try {
//      if (pw1Input.value.length < 8) {
      if (/.{8,}/.test(pw1Input.value) === false) {
         throw "Password must be at least 8 characters";
      } else if (pw1Input.value.localeCompare(pw2Input.value) !== 0) {
         throw "Passwords must match";
      } else if (/[a-zA-Z]/.test(pw1Input.value) === false) {
         throw "Password must contain at least one letter";
      } else if (/\d/.test(pw1Input.value) === false) {
         throw "Password must contain at least one number";
      } else if (/[!@#_]/.test(pw1Input.value) === false) {
         throw "Password must contain at least one of the following symbols: ! @ # _";
      }
      // remove any password error styling and message
      pw1Input.style.background = "";
      pw2Input.style.background = "";
      errorDiv.style.display = "none";
      errorDiv.innerHTML = "";
      // copy valid password to profile object
      profile.password = pw1Input.value;
   }
   catch(msg) {
      // display error message
      errorDiv.style.display = "block";
      errorDiv.innerHTML = msg;
      // change input style
      pw1Input.style.background = "rgb(255,233,233)";
      pw2Input.style.background = "rgb(255,233,233)";      
   }
}


function validateForm(evt) {
   if (evt.preventDefault) {
      evt.preventDefault(); // prevent form from submitting
   } else {
      evt.returnValue = false; // prevent form from submitting in IE8
   }
   formValidity = true; // reset value for revalidation
   validatePassword();
   validateAddress();
   validatPostalCode();
   validateEmail();
   validateUsername();
   validateLastname();
   validateProvince();
   validateCity();
   validateAge();
   if (formValidity === true) {
      document.getElementById("errorText").innerHTML = "";
      document.getElementById("errorText").style.display = "none";
      document.getElementsByTagName("form")[0].submit();
   } else {
      document.getElementById("errorText").innerHTML = "Please fix the indicated problems and then resubmit your order.";
      document.getElementById("errorText").style.display = "block";
      scroll(0,0);
   }
}


    function createEventListener() {
        var createBtn = document.getElementById("createBtn");
        if (createBtn.addEventListener) {
            createBtn.addEventListener("click", createBtn1, false);
        } else if (createBtn.attachEvent) {
            createBtn.attachEvent("onclick", createBtn1);
        }
    }

    function setUpPages() {
        createEventListener(); 
    }
if (window.addEventListener) {
    window.addEventListener("load", setUpPages, false);
} else if (window.attachEvent) {
    window.attachEvent("onload", setUpPages);
}
